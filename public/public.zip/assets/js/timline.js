timeline(document.querySelectorAll('.timeline'), {
	mode: 'horizontal',
	verticalStartPosition: 'left',
	visibleItems: 4
});